// src/api/ocr.js
import { apiGet, apiPostForm } from "./client"

// Maps wizard state's photo slot keys to the multipart field names the
// backend's /ocr/extract-batch/jobs endpoint expects (see kidney-backend's
// app/api/ocr.py start_extract_batch_job signature).
const SLOT_TO_FIELD = {
  hlaTypingReport: "hla_typing_report",
  beadSpecificityPage1: "bead_specificity_page_1",
  beadSpecificityPage2: "bead_specificity_page_2",
  crossmatchReport: "crossmatch_report",
}

function buildFormData(photos) {
  const formData = new FormData()
  let hasAny = false

  for (const [slot, fieldName] of Object.entries(SLOT_TO_FIELD)) {
    const file = photos[slot]
    if (file) {
      formData.append(fieldName, file)
      hasAny = true
    }
  }

  return hasAny ? formData : null
}

// Kicks off extraction as a server-owned background job and returns
// immediately with a job_id, instead of holding one HTTP connection open
// for however long the whole batch takes (bead specificity pages alone
// run 1.5-3 min each). The job keeps running on kidney-backend regardless
// of whether the caller keeps polling, navigates elsewhere, or drops the
// connection entirely — see getExtractionJob below, and
// WizardProvider.jsx's polling effect, which is what actually drives this
// from the wizard.
export function startExtractionJob(photos) {
  const formData = buildFormData(photos)
  if (!formData) {
    return Promise.reject(new Error("Upload at least one document before extracting."))
  }

  return apiPostForm("/ocr/extract-batch/jobs", formData)
}

// One snapshot of a job's current state: { job_id, status, documents, error }.
// `documents` is keyed by the same document_type strings SLOT_TO_FIELD's
// values use (e.g. "bead_specificity_page_1") -> { status, completed,
// total, ...whatever that document's extraction has produced so far }.
export function getExtractionJob(jobId) {
  return apiGet(`/ocr/extract-batch/jobs/${jobId}`)
}
