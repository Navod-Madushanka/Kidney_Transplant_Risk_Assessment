// src/utils/ocrNormalize.js
//
// Converts the raw OCR batch response (strings straight off the document)
// into the shapes the wizard reducer expects: ISO dates for <input
// type="date">, bare ABO codes for the blood-type selects, and numeric
// MFI values for the bead specificity table. Kept separate from the
// reducer so the reducer stays a pure "merge this shape into state"
// function, and all the real-world parsing quirks live in one place.

const MONTHS = {
  jan: "01", feb: "02", mar: "03", apr: "04", may: "05", jun: "06",
  jul: "07", aug: "08", sep: "09", oct: "10", nov: "11", dec: "12",
}

export function parseOcrDate(raw) {
  if (!raw) return ""
  const trimmed = raw.trim()

  // DD-Mon-YYYY, e.g. "16-Jan-1980"
  const monthMatch = trimmed.match(/^(\d{1,2})[-\s](\w{3})\w*[-\s](\d{4})$/)
  if (monthMatch) {
    const [, day, monthName, year] = monthMatch
    const month = MONTHS[monthName.toLowerCase().slice(0, 3)]
    if (month) return `${year}-${month}-${day.padStart(2, "0")}`
  }

  // DD.MM.YYYY or DD/MM/YYYY, e.g. "21.03.1976"
  const numericMatch = trimmed.match(/^(\d{1,2})[./](\d{1,2})[./](\d{4})$/)
  if (numericMatch) {
    const [, day, month, year] = numericMatch
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`
  }

  return ""
}

export function parseOcrBloodType(raw) {
  if (!raw) return ""
  // "B Positive" / "B Pos" / "B+" -> "B". Only the ABO group is stored;
  // Rh factor isn't part of BLOOD_TYPE_OPTIONS today.
  const match = raw.trim().match(/^(AB|A|B|O)/i)
  return match ? match[1].toUpperCase() : ""
}

export function parseOcrRhFactor(raw) {
  if (!raw) return ""
  // Both source reports print Rh as part of the same blood-type string
  // ("B Positive") that parseOcrBloodType reads the ABO group from -- this
  // is a second parse over that same raw value, not a separate OCR field.
  const trimmed = raw.trim().toLowerCase()
  if (/(positive|pos|\+)$/.test(trimmed)) return "+"
  if (/(negative|neg|-)$/.test(trimmed)) return "-"
  return ""
}

export function parseOcrMfi(raw) {
  // The backend now sends this as a real JSON number (or null for a row
  // the OCR couldn't read) rather than a formatted string -- handle both
  // so a genuine MFI of 0 (common at the low end of a bead-specificity
  // chart) survives instead of being treated as falsy and dropped.
  if (raw === null || raw === undefined || raw === "") return null
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : null
  const cleaned = String(raw).replace(/[^\d.]/g, "")
  const value = Number(cleaned)
  return Number.isFinite(value) && cleaned !== "" ? value : null
}

export function normalizeOcrBatchResponse(response) {
  const patientDetails = {
    full_name: response.patient_details?.full_name || "",
    nic_number: response.patient_details?.nic_number || "",
    date_of_birth: parseOcrDate(response.patient_details?.date_of_birth),
    blood_type: parseOcrBloodType(response.patient_details?.blood_type),
    rh_factor: parseOcrRhFactor(response.patient_details?.blood_type),
  }

  const donorDetails = {
    full_name: response.donor_details?.full_name || "",
    nic_number: response.donor_details?.nic_number || "",
    date_of_birth: parseOcrDate(response.donor_details?.date_of_birth),
    blood_type: parseOcrBloodType(response.donor_details?.blood_type),
    rh_factor: parseOcrRhFactor(response.donor_details?.blood_type),
  }

  // Part I (I8): a null MFI means the model flagged this row as illegible,
  // not that it doesn't exist -- the prompt deliberately keeps the row
  // rather than dropping it (a doctor can spot-check a flagged null far
  // more easily than notice a row that was silently never mentioned).
  // Filtering it out here undid that on arrival; only a genuinely empty
  // antigen (nothing to show at all) is dropped now. bead/page/panel/
  // conflict are carried through so BeadSpecificityStep can render the
  // unreadable-value marker and any tile-disagreement candidates.
  const beadSpecificity = (response.bead_specificity || [])
    .map((entry) => ({
      bead: entry.bead ?? null,
      antigen: entry.antigen,
      mfi: parseOcrMfi(entry.mfi),
      page: entry.page ?? null,
      panel: entry.panel ?? null,
      conflict: entry.conflict ?? null,
    }))
    .filter((entry) => entry.antigen)

  return {
    patientDetails,
    donorDetails,
    patientHla: response.patient_hla || [],
    donorHla: response.donor_hla || [],
    beadSpecificity,
    crossmatch: response.crossmatch || null,
    // A job can reach terminal "done" status with nothing actually
    // extracted -- e.g. ocr-service was unreachable (see
    // OcrJobDocumentStatus.errors, kidney-backend/app/schemas/ocr.py).
    // Dropped here until 2026-08-19: every caller treated `status===
    // "done"` alone as success, so a hard extraction failure silently
    // looked identical to "nothing found on this document" -- the doctor
    // saw an empty form with no indication anything had gone wrong.
    errors: response.errors || [],
  }
}