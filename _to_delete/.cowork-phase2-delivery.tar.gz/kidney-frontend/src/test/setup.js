// src/test/setup.js
// Loaded once before every test file (see the `test.setupFiles` entry in
// vite.config.js). Registers jest-dom's extra matchers (toBeInTheDocument,
// toHaveTextContent, etc.) globally so individual test files don't each
// need to import it.
import "@testing-library/jest-dom"
