# app/services/pra_bucket_service.py
"""
Step 4 of the sequential compatibility pipeline: bucket the calculated cPRA
percentage per app/reference_data/pra_buckets.py. cPRA itself is calculated
by cpra_service.py, against the frozen reference table in
app/reference_data/hla_antigen_frequencies.py — this only re-buckets that
output against the new spec's three ranges instead of treating cPRA as
pass/fail-only.

PRABucketResult.is_halted does NOT halt the pipeline — match_pipeline.py
never branches on it. It briefly did (cPRA > MAX_ACCEPTABLE_PRA_PERCENT
rejected the pairing outright), reverted 2026-08-08: cPRA measures how hard
a patient is to match against the *population*, not whether this specific
donor is compatible, so using it as a reject gate meant the more sensitised
a patient was, the more certainly the system refused the one compatible
donor they'd actually found. Steps 5 (DSA) and 6 (crossmatch) are the real
pair-specific gates for sensitisation-related risk. The field is kept
(rather than removed) as a simple "exceeds the >60% clinical threshold"
signal for display/reference — treat it as informational only, never as a
reason to stop the pipeline.

CPRAResult.has_sufficient_data is always True now that cPRA comes from a
frozen reference table rather than a live, possibly-too-small database
sample — the has_sufficient_data plumbing below is kept as cheap insurance
(and because the dataclass field itself still exists) rather than removed,
in case a future reference-table source can fail to load.
"""
from dataclasses import dataclass
from typing import Optional

from app.reference_data.pra_buckets import MAX_ACCEPTABLE_PRA_PERCENT, PRA_BUCKETS
from app.services.cpra_service import CPRAResult


@dataclass
class PRABucketResult:
    bucket_name: Optional[str]
    percent: Optional[float]
    is_halted: bool
    has_sufficient_data: bool


def calculate_pra_bucket(cpra_result: CPRAResult) -> PRABucketResult:
    if not cpra_result.has_sufficient_data:
        return PRABucketResult(
            bucket_name=None,
            percent=None,
            is_halted=False,
            has_sufficient_data=False,
        )

    percent = cpra_result.cpra_percentage
    bucket_name = _bucket_for_percent(percent)
    is_halted = percent > MAX_ACCEPTABLE_PRA_PERCENT

    return PRABucketResult(
        bucket_name=bucket_name,
        percent=percent,
        is_halted=is_halted,
        has_sufficient_data=True,
    )


def _bucket_for_percent(percent: float) -> str:
    """Review #2 bug 17: the old `min <= x <= max` loop over
    (0-29.999, 30-60, 60.001-100) left a real gap between 29.999 and 30 --
    a value like 29.9995 matched no bucket and silently fell through to
    `PRA_BUCKETS[-1]`, the *most severe* bucket (">60%"), the wrong
    direction to fail in for a clinical severity classification. Explicit
    half-open comparisons here make every real number in [0, inf) match
    exactly one bucket, so there's no gap and no fallback needed at all --
    this function is now total over its domain rather than needing an
    escape hatch for values it can't otherwise classify.
    """
    if percent < PRA_BUCKETS[0].max_percent:
        return PRA_BUCKETS[0].name
    if percent <= PRA_BUCKETS[1].max_percent:
        return PRA_BUCKETS[1].name
    return PRA_BUCKETS[2].name
