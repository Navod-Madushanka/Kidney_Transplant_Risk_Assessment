import { HLA_LOCUS_OPTIONS } from "../constants/clinicalEnums";
import { mergeDetails, mergeHlaRows, hasAnyValue } from "../utils/ocrHydrate";

// One empty typing row per locus, in the canonical order — mirrors the
// backend's HLA_LOCI list so nothing is silently missing when the pipeline
// later calls get_patient_hla_typing_dict / get_donor_hla_typing_dict.
function emptyHlaRows() {
  return HLA_LOCUS_OPTIONS.map((option) => ({
    locus: option.value,
    allele_1: "",
    allele_2: "",
  }));
}

export function buildInitialWizardState() {
  return {
    // Part E — which existing patient/donor this check runs against. The
    // wizard no longer creates a fresh patient/donor on every submission
    // (see api/compatibilityWizard.js); SubjectStep.jsx is where mode
    // becomes "select" and patientId/donorId/patientRecord/donorRecord get
    // set, either from a doctor's own pick there or pre-supplied by
    // NewCheckFromRecordsPage.jsx (see WizardProvider's lazy-init, same
    // pattern as photos.prefillPhotos below). patientRecord/donorRecord
    // hold a snapshot of each record's full_name/date_of_birth/blood_type/
    // rh_factor/nic_number AS OF SELECTION TIME -- used by DetailsStep to
    // detect an OCR read that disagrees with the linked record's
    // (immutable) blood type, so that comparison isn't fooled by
    // patient_details/donor_details having since been overwritten by OCR
    // itself. readiness is the last GET /compatibility/readiness response
    // for this pair.
    subject: {
      mode: "select",
      patientId: null,
      donorId: null,
      patientRecord: null,
      donorRecord: null,
      readiness: null,
    },

    // Phase 3 — raw uploads, keyed by what they contain rather than by
    // "patient"/"donor" position alone, since a mislabeled photo is a real
    // clinical risk. Values are File objects (or null) held only in memory;
    // OCR extraction results (if any) land in the structured fields below.
    photos: {
      hlaTypingReport: null,      // joint patient+donor HLA typing report
      beadSpecificityPage1: null, // bead specificity chart, page 1
      beadSpecificityPage2: null, // bead specificity chart, page 2 (report can run longer; page 2 is "at least the next page", not "the last page")
      crossmatchReport: null,     // T-cell/B-cell crossmatch + compatibility verdict
    },

    // Phase 4 — Payload 1
    patient_details: {
      full_name: "",
      nic_number: "",
      date_of_birth: "",
      blood_type: "",
      rh_factor: "",
    },
    donor_details: {
      full_name: "",
      nic_number: "",
      date_of_birth: "",
      blood_type: "",
      rh_factor: "",
    },

    // Phase 5 — Payload 2
    patient_hla: emptyHlaRows(),
    donor_hla: emptyHlaRows(),

    // Phase 6 — sensitization booleans (sent alongside Payload 3). No MFI
    // cutoff field here — the wizard used to show an editable "adjusted
    // cutoff" preview, but it was never actually sent to the backend, which
    // always recomputes Step 2 from its own fixed default and never used
    // the preview to adjust the real Step 5 DSA check either (see
    // app/reference_data/dsa_threshold.py) — removed 2026-08-08 rather than
    // leaving a doctor-facing field that silently did nothing.
    sensitization: {
      previous_transplant: false,
      pregnancy: false,
      blood_transfusion: false,
    },
    sensitization_dates: {
      previous_transplant: "",
      pregnancy: "",
      blood_transfusion: "",
    },

    // Phase 7 — Payload 3
    bead_specificity: [],
    // t_cell_result / b_cell_result / interpretation / remarks / test_date
    // may get pre-filled by OCR extraction on the photos step, giving the
    // doctor a head start rather than a blank form. is_positive is never
    // OCR-filled — it's the doctor's own confirmed reading of the
    // crossmatch result, entered on the Review step, and is what actually
    // gates Step 6 of the backend pipeline (see
    // CompatibilityCheckRequest.crossmatch in app/schemas/match_report.py).
    // interpretation and test_date stay reference-only — the backend's
    // CrossmatchInput schema doesn't have fields for them.
    crossmatch: {
      is_positive: null,
      t_cell_result: "",
      b_cell_result: "",
      interpretation: "",
      remarks: "",
      test_date: "",
    },

    // Wizard navigation guard: the furthest step the doctor has actually
    // reached, so ProtectedRoute-style guards can block jumping ahead via a
    // typed URL, while still allowing free navigation backward.
    furthestStepIndex: 0,

    // Doctor's explicit "I reviewed this against the source document"
    // confirmation, one flag per OCR-sourced document group -- required by
    // DetailsStep/HlaTypingStep/BeadSpecificityStep before Continue will
    // advance, but ONLY when that step's extraction.documents entry shows
    // OCR actually ran for it (see each file's own wasOcrExtracted /
    // wasAnyDocumentOcrExtracted check). Sent to the backend as
    // ocr_verified/details_verified on submission (see
    // api/compatibilityWizard.js) -- POST /compatibility/check refuses to
    // run at all while hla_typing/bead_specificity is unconfirmed
    // (app/api/compatibility.py), and (as of the details_verified fix)
    // the same is now true of `details`, rather than trusting a
    // vision-LLM misread of a name/DOB/blood-type into a hard reject.
    // crossmatch doesn't need an entry here: its gating field
    // (is_positive) is never OCR-filled in the first place, see the
    // crossmatch comment below.
    ocr_verified: {
      details: false,
      hla_typing: false,
      bead_specificity: false,
    },

    // Tracks the current/last document-extraction job, if any. Lives here
    // (rather than as PhotoUploadsStep local state) specifically so it
    // survives navigating to another wizard step — extraction runs as a
    // background job on kidney-backend (see app/services/ocr_job_service.py)
    // that keeps going regardless of which page is open, and
    // WizardProvider's polling effect (not any one step component) is what
    // watches jobId and feeds completed documents into the fields above via
    // HYDRATE_FROM_OCR. Without this living at the wizard level, navigating
    // away from Photos mid-extraction used to silently kill every visible
    // sign of progress even though the extraction itself kept running.
    extraction: {
      jobId: null,
      status: "idle", // idle | running | done | failed
      documents: {}, // { [document_type]: { status, completed, total, errors, ... } } -- last poll snapshot
      error: null,
      // True once useExtractionJobPolling has seen several consecutive
      // failed polls (see its STALLED_AFTER_FAILURES) -- NOT the same as
      // the job itself failing: the job very likely keeps running
      // server-side, polling has just lost contact with the backend. Lets
      // PhotoUploadsStep say so instead of leaving a frozen progress bar
      // with no explanation. Part H fix.
      pollingStalled: false,
    },
  };
}

export const WIZARD_ACTIONS = {
  SET_SUBJECT: "SET_SUBJECT",
  SET_READINESS: "SET_READINESS",
  SET_LINKED_RECORDS: "SET_LINKED_RECORDS",
  SET_PHOTO: "SET_PHOTO",
  SET_PATIENT_DETAILS: "SET_PATIENT_DETAILS",
  SET_DONOR_DETAILS: "SET_DONOR_DETAILS",
  SET_PATIENT_HLA_ROW: "SET_PATIENT_HLA_ROW",
  SET_DONOR_HLA_ROW: "SET_DONOR_HLA_ROW",
  SET_SENSITIZATION: "SET_SENSITIZATION",
  SET_OCR_VERIFIED: "SET_OCR_VERIFIED",
  SET_BEAD_SPECIFICITY: "SET_BEAD_SPECIFICITY",
  SET_CROSSMATCH: "SET_CROSSMATCH",
  HYDRATE_FROM_OCR: "HYDRATE_FROM_OCR",
  UNLOCK_STEP: "UNLOCK_STEP",
  RESET: "RESET",
  SET_SENSITIZATION_DATE: "SET_SENSITIZATION_DATE",
  START_EXTRACTION_JOB: "START_EXTRACTION_JOB",
  SET_EXTRACTION_JOB_STATUS: "SET_EXTRACTION_JOB_STATUS",
  SET_EXTRACTION_JOB_ERROR: "SET_EXTRACTION_JOB_ERROR",
  SET_EXTRACTION_POLLING_STALLED: "SET_EXTRACTION_POLLING_STALLED",
};

function updateHlaRow(rows, locus, patch) {
  return rows.map((row) => (row.locus === locus ? { ...row, ...patch } : row));
}

export function wizardReducer(state, action) {
  switch (action.type) {
    case WIZARD_ACTIONS.SET_SUBJECT:
      return {
        ...state,
        subject: { ...state.subject, ...action.patch },
      };

    case WIZARD_ACTIONS.SET_READINESS:
      return {
        ...state,
        subject: { ...state.subject, readiness: action.readiness },
      };

    case WIZARD_ACTIONS.SET_LINKED_RECORDS:
      return {
        ...state,
        subject: {
          ...state.subject,
          patientRecord: action.patientRecord,
          donorRecord: action.donorRecord,
        },
      };

    case WIZARD_ACTIONS.SET_PHOTO:
      return {
        ...state,
        photos: { ...state.photos, [action.slot]: action.file },
      };

    case WIZARD_ACTIONS.SET_PATIENT_DETAILS:
      return {
        ...state,
        patient_details: { ...state.patient_details, ...action.patch },
      };

    case WIZARD_ACTIONS.SET_DONOR_DETAILS:
      return {
        ...state,
        donor_details: { ...state.donor_details, ...action.patch },
      };

    case WIZARD_ACTIONS.SET_PATIENT_HLA_ROW:
      return {
        ...state,
        patient_hla: updateHlaRow(state.patient_hla, action.locus, action.patch),
      };

    case WIZARD_ACTIONS.SET_DONOR_HLA_ROW:
      return {
        ...state,
        donor_hla: updateHlaRow(state.donor_hla, action.locus, action.patch),
      };

    case WIZARD_ACTIONS.SET_SENSITIZATION:
      return {
        ...state,
        sensitization: { ...state.sensitization, ...action.patch },
      };

    case WIZARD_ACTIONS.SET_OCR_VERIFIED:
      return {
        ...state,
        ocr_verified: { ...state.ocr_verified, [action.group]: action.verified },
      };

    case WIZARD_ACTIONS.SET_BEAD_SPECIFICITY:
      return { ...state, bead_specificity: action.rows };

    case WIZARD_ACTIONS.SET_CROSSMATCH:
      return {
        ...state,
        crossmatch: { ...state.crossmatch, ...action.patch },
      };

    case WIZARD_ACTIONS.HYDRATE_FROM_OCR: {
      const { patientDetails, donorDetails, patientHla, donorHla, beadSpecificity, crossmatch } =
        action.payload;

      // A fresh extraction overwriting fields with output nobody has seen
      // yet invalidates any earlier verification of that same document
      // group -- otherwise re-uploading a corrected photo after already
      // checking "reviewed" would silently keep trusting the old
      // confirmation against new, unreviewed data.
      const detailsChanged = hasAnyValue(patientDetails) || hasAnyValue(donorDetails);
      const hlaChanged =
        (patientHla && patientHla.length > 0) || (donorHla && donorHla.length > 0);
      const beadSpecificityChanged = beadSpecificity && beadSpecificity.length > 0;

      return {
        ...state,
        patient_details: mergeDetails(state.patient_details, patientDetails),
        donor_details: mergeDetails(state.donor_details, donorDetails),
        patient_hla: mergeHlaRows(state.patient_hla, patientHla),
        donor_hla: mergeHlaRows(state.donor_hla, donorHla),
        bead_specificity:
          beadSpecificity && beadSpecificity.length > 0 ? beadSpecificity : state.bead_specificity,
        crossmatch: crossmatch ? { ...state.crossmatch, ...crossmatch } : state.crossmatch,
        ocr_verified: {
          details: detailsChanged ? false : state.ocr_verified.details,
          hla_typing: hlaChanged ? false : state.ocr_verified.hla_typing,
          bead_specificity: beadSpecificityChanged ? false : state.ocr_verified.bead_specificity,
        },
      };
    }

    case WIZARD_ACTIONS.UNLOCK_STEP:
      return {
        ...state,
        furthestStepIndex: Math.max(state.furthestStepIndex, action.index),
      };

    case WIZARD_ACTIONS.RESET:
      return buildInitialWizardState();

    case WIZARD_ACTIONS.SET_SENSITIZATION_DATE:
      return {
        ...state,
        sensitization_dates: {
          ...state.sensitization_dates,
          [action.eventType]: action.date,
        },
      };

    // Fired the moment POST /ocr/extract-batch/jobs returns a job_id --
    // seeds one "pending" entry per requested document so the progress
    // list has something to show immediately, before the background job
    // has even started running.
    case WIZARD_ACTIONS.START_EXTRACTION_JOB: {
      const documents = {};
      for (const documentType of action.documentTypes) {
        documents[documentType] = { status: "pending", completed: 0, total: 1, errors: [] };
      }
      return {
        ...state,
        extraction: {
          jobId: action.jobId,
          status: "running",
          documents,
          error: null,
          pollingStalled: false,
        },
      };
    }

    // Applies one GET .../jobs/{id} poll response -- a full snapshot, not
    // a delta, so this just replaces extraction.documents/status wholesale
    // rather than merging. WizardProvider's polling effect is what decides
    // when a document has newly finished and dispatches HYDRATE_FROM_OCR
    // for it separately; this action only updates the progress list itself.
    case WIZARD_ACTIONS.SET_EXTRACTION_JOB_STATUS:
      return {
        ...state,
        extraction: {
          ...state.extraction,
          status: action.status,
          documents: action.documents,
        },
      };

    // A poll request itself failed (network blip, server error) rather
    // than the job failing -- distinct from a document-level error, which
    // lives in extraction.documents[...].errors and doesn't stop the job.
    case WIZARD_ACTIONS.SET_EXTRACTION_JOB_ERROR:
      return {
        ...state,
        extraction: { ...state.extraction, status: "failed", error: action.error },
      };

    // Polling losing contact with the backend, distinct from the job
    // itself failing -- see useExtractionJobPolling's onPollingStalled and
    // extraction.pollingStalled's own comment above. Never touches status.
    case WIZARD_ACTIONS.SET_EXTRACTION_POLLING_STALLED:
      return {
        ...state,
        extraction: { ...state.extraction, pollingStalled: action.isStalled },
      };

    default:
      return state;
  }
}