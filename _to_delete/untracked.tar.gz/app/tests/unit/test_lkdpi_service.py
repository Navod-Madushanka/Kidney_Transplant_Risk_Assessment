# app/tests/unit/test_lkdpi_service.py
import pytest

from app.reference_data.lkdpi_model import SOURCE_CITATION, WEIGHT_RATIO_CAP
from app.services.lkdpi_service import (
    FIELD_LABELS,
    REQUIRED_FIELDS,
    LKDPIInput,
    calculate_lkdpi,
)


def _full_input(**overrides):
    values = dict(
        donor_age_years=60,
        donor_egfr=90.0,
        donor_bmi=25.0,
        donor_race="white",
        donor_smoking_status="never",
        donor_systolic_bp=130.0,
        donor_sex="male",
        recipient_sex="female",
        abo_incompatible=False,
        donor_biologically_related=True,
        hla_b_mismatches=1,
        hla_dr_mismatches=1,
        donor_weight_kg=70.0,
        recipient_weight_kg=70.0,
    )
    values.update(overrides)
    return LKDPIInput(**values)


def test_worked_example_matches_hand_calculation():
    """By hand, from app/reference_data/lkdpi_model.py's coefficients:
        age over 50:      1.85 * (60-50)        = +18.500
        eGFR:             -0.381 * 90            = -34.290
        BMI:              1.17 * 25              = +29.250
        African-American: white -> not applied   =   0.000
        Smoking:          never -> not applied    =   0.000
        Systolic BP:      0.44 * 130              = +57.200
        Both male:        male/female -> no       =   0.000
        ABO incompatible: False -> no              =   0.000
        Unrelated:        related=True -> no        =   0.000
        HLA-B:            8.57 * 1                = +8.570
        HLA-DR:           8.26 * 1                = +8.260
        Weight ratio:     -50.87 * min(1.0, 0.9)  = -45.783
        intercept                                  = -11.300
        sum = 18.5 -34.29 +29.25 +57.2 +8.57 +8.26 -45.783 -11.3 = 30.407
    """
    result = calculate_lkdpi(_full_input())

    assert result.has_sufficient_data is True
    assert result.score == pytest.approx(30.41, abs=0.01)
    assert result.band == "moderate"


@pytest.mark.parametrize("field_name", REQUIRED_FIELDS)
def test_missing_input_refuses_rather_than_guesses(field_name):
    result = calculate_lkdpi(_full_input(**{field_name: None}))

    assert result.score is None
    assert result.has_sufficient_data is False
    assert FIELD_LABELS[field_name] in result.missing_inputs


@pytest.mark.parametrize(
    "ratio_inputs",
    [
        {"donor_weight_kg": 90.0, "recipient_weight_kg": 100.0},  # ratio 0.9
        {"donor_weight_kg": 100.0, "recipient_weight_kg": 100.0},  # ratio 1.0
        {"donor_weight_kg": 150.0, "recipient_weight_kg": 100.0},  # ratio 1.5
    ],
)
def test_weight_ratio_caps_at_point_nine(ratio_inputs):
    result = calculate_lkdpi(_full_input(**ratio_inputs))
    weight_contribution = next(
        c for c in result.contributions if c["label"].startswith("Donor/recipient weight ratio")
    )
    # Contribution points are rounded to 2 decimals for display, so compare
    # against that same rounding rather than the raw -45.783.
    assert weight_contribution["points"] == pytest.approx(
        round(-50.87 * WEIGHT_RATIO_CAP, 2), abs=0.01
    )


def test_age_hinge_at_and_below_fifty_contributes_zero():
    for age in (50, 45):
        result = calculate_lkdpi(_full_input(donor_age_years=age))
        age_term = next(c for c in result.contributions if c["label"].startswith("Donor age over 50"))
        assert age_term["points"] == 0.0


def test_age_hinge_above_fifty_contributes_correctly():
    result = calculate_lkdpi(_full_input(donor_age_years=60))
    age_term = next(c for c in result.contributions if c["label"].startswith("Donor age over 50"))
    assert age_term["points"] == pytest.approx(18.5, abs=0.001)


def test_race_other_is_not_population_validated():
    result = calculate_lkdpi(_full_input(donor_race="other"))
    assert result.population_validated is False
    assert result.population_extrapolation_disclaimer is not None


@pytest.mark.parametrize("race", ["black", "white"])
def test_race_black_or_white_is_population_validated(race):
    result = calculate_lkdpi(_full_input(donor_race=race))
    assert result.population_validated is True
    assert result.population_extrapolation_disclaimer is None


def test_donor_african_american_gets_the_race_term():
    baseline = calculate_lkdpi(_full_input(donor_race="white"))
    black = calculate_lkdpi(_full_input(donor_race="black"))
    assert black.score == pytest.approx(baseline.score + 22.34, abs=0.001)


def test_contributions_sum_to_score_minus_intercept():
    result = calculate_lkdpi(_full_input())
    total_contribution_points = sum(c["points"] for c in result.contributions)
    # intercept is -11.30 and not itself a "contribution" entry.
    assert total_contribution_points == pytest.approx(result.score - (-11.30), abs=0.01)


def test_single_factor_override_triggers_above_threshold():
    # The default worked example's largest-magnitude term is systolic BP
    # (0.44 * 130 = +57.2), well past SINGLE_FACTOR_OVERRIDE_THRESHOLD (25)
    # on its own -- single_factor_override always names the single largest
    # contribution, not necessarily the first one computed.
    result = calculate_lkdpi(_full_input())
    assert result.single_factor_override is not None
    assert result.single_factor_override["label"].startswith("Donor systolic BP")
    assert result.single_factor_override["points"] == pytest.approx(57.2, abs=0.01)


def test_no_single_factor_override_when_all_terms_are_small():
    # Chosen so every individual term's magnitude stays at or below the
    # +25 override threshold (unlike the default worked example, where the
    # systolic BP term alone is +57.2) -- values are intentionally
    # unrealistic (SBP 50) purely to keep every term small for this test;
    # lkdpi_service.py flags out-of-range values but never rejects them.
    result = calculate_lkdpi(
        _full_input(
            donor_age_years=50,
            donor_egfr=60.0,
            donor_bmi=20.0,
            donor_systolic_bp=50.0,
            hla_b_mismatches=0,
            hla_dr_mismatches=0,
            donor_weight_kg=30.0,
            recipient_weight_kg=100.0,
        )
    )
    assert all(abs(c["points"]) <= 25.0 for c in result.contributions)
    assert result.single_factor_override is None


def test_range_warnings_are_flagged_not_clamped():
    result = calculate_lkdpi(
        _full_input(donor_egfr=10.0, donor_bmi=50.0, donor_systolic_bp=200.0, donor_age_years=90)
    )
    assert result.has_sufficient_data is True  # still computed, just flagged
    assert any("eGFR" in flag for flag in result.values_outside_model_range)
    assert any("BMI" in flag for flag in result.values_outside_model_range)
    assert any("systolic BP" in flag for flag in result.values_outside_model_range)
    assert any("age" in flag for flag in result.values_outside_model_range)


def test_in_range_values_are_not_flagged():
    result = calculate_lkdpi(_full_input())
    assert result.values_outside_model_range == []


def test_source_citation_is_present():
    result = calculate_lkdpi(_full_input())
    assert result.source_citation == SOURCE_CITATION
